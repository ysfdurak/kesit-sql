# Operasyon, sistem görünümleri ve ETL: kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| etl_dim_sube | 6 | `SUM(guncel)` = 5 |
| etl_fact_hareket | 0 | `SUM(sube_key)` = null |
| etl_red | 0 | `SUM(stg_id)` = null |
| etl_stg_hareket | 18 | `SUM(stg_id)` = 171 |
| etl_stg_sube | 5 |  |
| etl_yukleme_log | 3 | `SUM(batch_id)` = 123 |
| msdb_backupset | 348 | `SUM(backup_set_id)` = 2496378 |
| msdb_sysjobhistory | 30 | `SUM(instance_id)` = 465 |
| msdb_sysjobs | 4 | `SUM(enabled)` = 3 |
| ops_access_log | 3991 |  |
| ops_logins | 10 | `SUM(off_hours_ok)` = 6 |
| ops_plan_stats | 335 | `SUM(exec_count)` = 1926 |
| ops_query_log | 7607 | `SUM(duration_ms)` = 670507 |
| sys_database_permissions | 13 | `SUM(major_id)` = 13035 |
| sys_database_principals | 12 | `SUM(principal_id)` = 32872 |
| sys_database_role_members | 7 | `SUM(role_principal_id)` = 49239 |
| sys_dm_db_index_physical_stats | 14 | `SUM(database_id)` = 70 |
| sys_dm_db_index_usage_stats | 12 | `SUM(database_id)` = 60 |
| sys_dm_exec_query_stats | 8 | `SUM(execution_count)` = 283106 |
| sys_dm_exec_requests | 6 | `SUM(session_id)` = 414 |
| sys_dm_exec_sessions | 8 | `SUM(session_id)` = 560 |
| sys_dm_exec_sql_text | 13 | `SUM(dbid)` = 65 |
| sys_dm_os_sys_info | 1 |  |
| sys_dm_os_wait_stats | 10 | `SUM(waiting_tasks_count)` = 14543400 |
| sys_dm_tran_active_transactions | 3 | `SUM(transaction_id)` = 27006 |
| sys_dm_tran_session_transactions | 3 | `SUM(session_id)` = 203 |
| sys_indexes | 14 | `SUM(object_id)` = 14033 |
| sys_objects | 5 | `SUM(object_id)` = 5015 |
| sys_query_store_plan | 4 | `SUM(plan_id)` = 87 |
| sys_query_store_query | 3 | `SUM(query_id)` = 22 |
| sys_query_store_query_text | 3 | `SUM(query_text_id)` = 1506 |
| sys_query_store_runtime_stats | 56 | `SUM(runtime_stats_id)` = 1596 |
| sys_query_store_runtime_stats_interval | 34 | `SUM(runtime_stats_interval_id)` = 595 |
