# Lezzet Kurye (yemek teslimatı): kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| lk_couriers | 60 | `SUM(rating)` = 248.69 |
| lk_customers | 1209 |  |
| lk_menu_items | 168 | `SUM(price)` = 28405 |
| lk_order_lines | 14974 | `SUM(qty)` = 19420 |
| lk_orders | 7178 | `SUM(delivery_fee)` = 79894.4 |
| lk_ratings | 3979 | `SUM(food_score)` = 16325 |
| lk_restaurants | 30 | `SUM(commission_pct)` = 515 |
