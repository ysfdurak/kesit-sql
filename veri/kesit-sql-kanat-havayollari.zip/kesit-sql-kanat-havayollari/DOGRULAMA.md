# Kanat Havayolları: kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| hv_aircraft | 15 | `SUM(seats)` = 3083 |
| hv_airports | 19 | `SUM(tz_offset)` = 48 |
| hv_bookings | 5020 | `SUM(price)` = 9760445 |
| hv_delays | 1350 | `SUM(minutes)` = 72243 |
| hv_flights | 3173 | `SUM(pax)` = 495356 |
| hv_passengers | 900 | `SUM(birth_year)` = 1779447 |
| hv_repositioning | 443 |  |
| hv_routes | 45 | `SUM(distance_km)` = 53268 |
