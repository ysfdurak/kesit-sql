# Kanat Havayolları · Kesit SQL veri paketi

Kesit SQL'deki derslerin ve alıştırmaların bu bölümünü **kendi veritabanında** çalışmak için. Tablolar ve sütun türleri uygulamanın Veri setleri sayfasındakiyle aynıdır.

## İçindekiler

| Dosya | Ne için |
|---|---|
| `sqlserver.sql` | SQL Server (SSMS, Azure Data Studio, sqlcmd) |
| `postgresql.sql` | PostgreSQL (psql, pgAdmin, DBeaver) |
| `mysql.sql` | MySQL 8 (MySQL Workbench, mysql istemcisi) |
| `oracle.sql` | Oracle 19c ve üstü (SQL Developer, SQL*Plus) |
| `kesit-sql-kanat-havayollari.sqlite` | Kurulumsuz: DB Browser for SQLite, DBeaver ya da Python `sqlite3` ile doğrudan aç |
| `DOGRULAMA.md` | Kurulumdan sonra karşılaştıracağın satır sayıları ve kontrol toplamları |

8 tablo, 10.965 satır.

## Kurulum

1. **Boş bir veritabanı** oluştur (ör. `CREATE DATABASE kesit;`). Betikler tabloları siler değil, yeniden oluşturur; aynı veritabanında ikinci kez çalıştırırsan "tablo zaten var" hatası alırsın.
2. Betiği çalıştır:
   - SQL Server: `sqlcmd -S localhost -d kesit -i sqlserver.sql` (büyük dosyayı SSMS'te açmak yerine sqlcmd daha hızlıdır). Türkçe sıralama için veritabanını `Turkish_CI_AS` harmanlamasıyla oluştur.
   - PostgreSQL: `psql -d kesit -f postgresql.sql`
   - MySQL: `mysql kesit < mysql.sql`. Türkçe karşılaştırma için `CREATE DATABASE kesit CHARACTER SET utf8mb4 COLLATE utf8mb4_tr_0900_ai_ci;`
   - Oracle: SQL*Plus ya da SQL Developer'da `@oracle.sql`. Tablo ve sütun adları büyük harfle tanımlıdır; sorgularda tırnaksız yazabilirsin. Ayrılmış sözcük olan sütun adlarını (varsa) çift tırnakla ve büyük harfle yaz.
3. Betiğin sonundaki satır sayısı sorgusunu çalıştır, [DOGRULAMA.md](DOGRULAMA.md) ile karşılaştır.

## Derslerle birlikte

Uygulamada her dersin konu sayfasında **Kendi veritabanında çalış** bölümü var: o dersin görev kâğıdını (.md) seçtiğin SQL türünde indirirsin. Her görevin sorusu ve beklenen sonuç tablosu yazılıdır, çözümler en sondadır.

## Bilinen farklar

- Uygulama SQLite üzerinde çalışan bir taklit motordur. Sıralaması belirtilmemiş sorgularda satır sırası ve ondalık gösterim veritabanına göre değişebilir; tutarlar aynı olmalıdır.
- Oracle'da boş metin ('') NULL sayılır; boş metin içeren satırlar Oracle'da NULL olarak yüklenir.
- Yabancı anahtar olarak kurulmayan ilişkiler:
- Yok: bütün ilişkiler yabancı anahtar olarak kuruldu.

Kaynak: [Kesit SQL](https://ysfdurak.github.io/kesit-sql/) · Yusuf Durak. Veri ve içerik CC BY-NC 4.0, kod PolyForm Shield 1.0.0.
