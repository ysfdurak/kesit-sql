# Pedal İzmir (bisiklet paylaşımı): kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| bk_bikes | 700 |  |
| bk_maintenance | 1400 |  |
| bk_rebalancing | 28180 |  |
| bk_stations | 62 | `SUM(capacity)` = 1405 |
| bk_trips | 116517 | `SUM(distance_km)` = 584426.07 |
| bk_users | 6000 | `SUM(birth_year)` = 11054640 |
| bk_weather | 2208 | `SUM(temp_c)` = 66655.4 |
