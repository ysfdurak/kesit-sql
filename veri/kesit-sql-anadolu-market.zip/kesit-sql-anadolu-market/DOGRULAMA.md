# Anadolu Market (e-ticaret): kontrol değerleri

**Doğrulama durumu:** Windows'ta doğrulandı (28 Kasım 2026, SQL Server, SSMS 18): `sqlserver.sql` hatasız kuruldu; aşağıdaki satır sayıları ve kontrol toplamlarının hepsi tuttu.

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| ab_test | 2000 | `SUM(revenue)` = 114071.61 |
| customers | 150 | `SUM(birth_year)` = 297530 |
| departments | 7 |  |
| employees | 27 | `SUM(salary)` = 1856000 |
| order_items | 1620 | `SUM(quantity)` = 2597 |
| orders | 910 |  |
| price_updates | 18 | `SUM(new_price)` = 55744 |
| products | 40 | `SUM(price)` = 64622 |
| raw_signups | 52 | `SUM(id)` = 1065 |
| web_events | 2819 | `SUM(user_id)` = 3663094 |
