# Pusula A.Ş. (insan kaynakları): kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| ik_candidates | 14159 |  |
| ik_departments | 12 |  |
| ik_employees | 2199 | `SUM(birth_year)` = 4370480 |
| ik_job_history | 2848 |  |
| ik_leaves | 16577 | `SUM(days)` = 53839 |
| ik_positions | 67 | `SUM(level)` = 234 |
| ik_requisitions | 807 |  |
| ik_reviews | 6618 | `SUM(review_year)` = 13379763 |
| ik_salaries | 11352 | `SUM(monthly_gross)` = 501899400 |
| ik_survey | 2222 | `SUM(enps)` = 15973 |
| ik_training | 3126 | `SUM(hours)` = 14504 |
