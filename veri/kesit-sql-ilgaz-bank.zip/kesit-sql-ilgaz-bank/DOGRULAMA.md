# Ilgaz Bank: kontrol değerleri

Kurulumdan sonra her betiğin sonundaki satır sayısı sorgusunu çalıştır ve bu tabloyla karşılaştır. Toplam sütunu ondalık türlerin doğru yüklendiğini gösterir.

| Tablo | Satır | Kontrol toplamı |
|---|---:|---|
| bank_accounts | 849 | `SUM(credit_limit)` = 8170000 |
| bank_branches | 12 | `SUM(opened_year)` = 24145 |
| bank_customers | 500 | `SUM(risk_score)` = 2691 |
| bank_fx | 524 |  |
| bank_txns | 42284 | `SUM(amount)` = 125012817.55 |
